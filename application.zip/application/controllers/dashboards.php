<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Dashboards extends CI_Controller {
    public function index() 
    {   
        $current_user_id = $this->session->userdata('user_id');
        if(!$current_user_id) { 
            redirect("users");
        } 
        else {
            $total = $this->dashboard->total();
            $pending = $this->dashboard->pending();
            $approved = $this->dashboard->approved();
            $cancelled = $this->dashboard->cancelled();
            $po_total = $this->dashboard->po_total();
            $po_pending = $this->dashboard->po_pending();
            $po_approved = $this->dashboard->po_approved();
            $po_cancelled = $this->dashboard->po_cancelled();
            $data = array('total'=>$total, 'pending'=>$pending, 'approved'=>$approved, 'cancel'=>$cancelled, 'po_total'=>$po_total, 'po_pending'=>$po_pending, 'po_approved'=>$po_approved, 'po_cancel'=>$po_cancelled);
            $this->load->view('templates/includes/header');
            $this->load->view('templates/includes/sidebar');
            $this->load->view('admin/dist/index', $data);
            $this->load->view('templates/includes/footer');
        }
    }

    public function users() 
    {
        $result = $this->user->get_all_user();
        $list = array('list' => $result);
        $this->load->view('templates/includes/header');
        $this->load->view('templates/includes/sidebar');
        $this->load->view('admin/dist/list_users',$list);
        $this->load->view('templates/includes/footer');
    }

    public function addusers() 
    {
        $this->load->view('templates/includes/header');
        $this->load->view('templates/includes/sidebar');
        $this->load->view('admin/dist/add_users');
        $this->load->view('templates/includes/footer');
    }

    public function vendor() 
    {
        $res = $this->vendor->get_allvendor();
        $list = array('list'=> $res);
        $this->load->view('templates/includes/header');
        $this->load->view('templates/includes/sidebar');
        $this->load->view('admin/dist/add_vendor', $list);
        $this->load->view('templates/includes/footer');
    }

    public function item() 
    {
        $res = $this->item->get_allitem();
        $list = array('list'=> $res);
        $this->load->view('templates/includes/header');
        $this->load->view('templates/includes/sidebar');
        $this->load->view('admin/dist/add_item', $list);
        $this->load->view('templates/includes/footer');
    }
    
    public function request() 
    {
        redirect('requests');
    }

    public function pr_details() 
    {
        $date = date("Y-m-d, H:i:s");
        $pr_no = $this->request->get_last_pr();
        $create = $this->request->save_pr($pr_no);
        $details = $this->request->get_save_pr($create);
        $this->session->set_userdata('last_save_pr', ''.$create.'');
        $this->session->set_userdata('activity', 'Attepmt to create PR '.$pr_no.'');
        $this->activity->log($this->session->userdata('user_id'));
        $list = array('pr_no' => $create, 'date' => $date, 'details'=>$details);
        $this->load->view('templates/includes/header');
        $this->load->view('templates/includes/sidebar');
        $this->load->view('admin/dist/add_pr', $list);
        $this->load->view('templates/includes/footer');
    }
    
    public function order() 
    {
        $this->load->view('templates/includes/header');
        $this->load->view('templates/includes/sidebar');
        $this->load->view('admin/dist/add_order');
        $this->load->view('templates/includes/footer');
    }

    public function list_request() 
    {
        $result = $this->request->fetch_all_generated_request();
        $list = array('list' => $result);
        $this->load->view('templates/includes/header');
        $this->load->view('templates/includes/sidebar');
        $this->load->view('admin/dist/list_request',$list);
        $this->load->view('templates/includes/footer');
    }
    
    public function list_order() 
    {
        $result = $this->request->fetch_all_generated_order();
        $list = array('list' => $result);
        $this->load->view('templates/includes/header');
        $this->load->view('templates/includes/sidebar');
        $this->load->view('admin/dist/list_order',$list);
        $this->load->view('templates/includes/footer');
    }

    public function list_logs() 
    {
        $result = $this->activity->fetch_all_logs();
        $list = array('list' => $result);
        $this->load->view('templates/includes/header');
        $this->load->view('templates/includes/sidebar');
        $this->load->view('admin/dist/list_logs',$list);
        $this->load->view('templates/includes/footer');
    }

    public function approval_request() 
    {   
        $approver = $this->session->userdata('approver');
        $result = $this->request->fetch_all_request_approval($approver);
        $list = array('list' => $result);
        $this->load->view('templates/includes/header');
        $this->load->view('templates/includes/sidebar');
        $this->load->view('admin/dist/approval_request',$list);
        $this->load->view('templates/includes/footer');
    }
    
    public function approval_order() 
    {   
        $approver = $this->session->userdata('approver');
        $result = $this->request->fetch_all_order_approval($approver);
        $list = array('list' => $result);
        $this->load->view('templates/includes/header');
        $this->load->view('templates/includes/sidebar');
        $this->load->view('admin/dist/approval_order',$list);
        $this->load->view('templates/includes/footer');
    }

    
    public function report() 
    {   
        $dtable = $this->report->daily_table();
        $po_dtable = $this->report->po_daily_table();
        $wtable = $this->report->weekly_table();
        $po_wtable = $this->report->po_weekly_table();
        $mtable = $this->report->monthly_table();
        $po_mtable = $this->report->po_monthly_table();
        $data = array('dtable'=>$dtable, 'po_dtable'=>$po_dtable, 'wtable'=>$wtable, 'po_wtable'=>$po_wtable, 'mtable'=>$mtable, 'po_mtable'=>$po_mtable);

        $dchart = $this->report->daily_chart();
        $ychart = $this->report->ydaily_chart();
        $wchart = $this->report->weekly_chart();
        $wmax = $this->report->weekly_max();
        $mchart = $this->report->monthly_chart();
        $mmax = $this->report->monthly_max();
        $chart = array('wchart'=>$wchart, 'wmax'=>$wmax, 'dchart'=>$dchart, 'ychart'=>$ychart, 'mchart'=>$mchart, 'mmax'=>$mmax);

        $this->load->view('templates/includes/header');
        $this->load->view('templates/includes/sidebar');
        $this->load->view('admin/dist/view_report',$data);
        $this->load->view('templates/includes/footer',$chart);
    }

    public function logoff() 
    {
        $this->session->sess_destroy();
        $this->session->set_userdata('activity', ''.$this->session->userdata('firstname').' successfully logged out');
        $this->activity->log($this->session->userdata('user_id'));
        redirect("users");   
    }

    
}
